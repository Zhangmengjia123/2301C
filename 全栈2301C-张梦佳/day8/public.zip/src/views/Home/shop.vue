<script setup lang='ts'>



</script>
<template>
<div>
shop




</div>
</template>
<style lang='scss' scoped>





</style>